# encoding: utf-8

def test_import_coloransi():
    from IPython.utils import coloransi

def test_import_generics():
    from IPython.utils import generics

def test_import_ipstruct():
    from IPython.utils import ipstruct

def test_import_PyColorize():
    from IPython.utils import PyColorize

def test_import_strdispatch():
    from IPython.utils import strdispatch

def test_import_wildcard():
    from IPython.utils import wildcard

