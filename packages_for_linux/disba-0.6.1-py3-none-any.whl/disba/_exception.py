__all__ = [
    "DispersionError",
]


class DispersionError(Exception):
    pass
