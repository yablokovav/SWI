# Author:  Lisandro Dalcin
# Contact: dalcinl@gmail.com

if __name__ == '__main__':
    import sys
    sys.dont_write_bytecode = True
    from main import main
    main(module=None)
