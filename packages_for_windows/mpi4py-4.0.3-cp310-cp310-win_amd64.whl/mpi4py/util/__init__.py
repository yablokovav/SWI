# Author:  Lisandro Dalcin
# Contact: dalcinl@gmail.com
"""Miscellaneous utilities."""
